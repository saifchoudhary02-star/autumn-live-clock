# Autumn Live Clock (Android)

A starter Android project reconstructed from the supplied project handover specification.

## Included in this starter
- Compose customization dashboard with four scene palettes
- Digital/analog clock preview and 12/24-hour selector
- Selectable digital and analog style labels
- Individual animation toggles and a live wallpaper service with animated falling leaves
- GitHub Actions workflow to compile a debug APK in the cloud

## Important implementation limits
This is a first installable-build candidate, not the fully finished specification. Weather and location providers, real battery data, sunrise/sunset, functional home-screen widget sizes/skins, persistent settings, and several individually animated effects still need implementation and device testing. The dashboard currently previews selected styles; style-specific typography/colour/position controls are not complete.

## Build APK in GitHub Actions
1. Create a GitHub repository and upload the *contents* of this folder, including the hidden `.github` folder.
2. Open the repository's **Actions** tab.
3. Select **Build Autumn Live Clock APK** and choose **Run workflow**.
4. When the run succeeds, open it and download the `Autumn-Live-Clock-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on the Android phone. Android may ask you to allow installs from that source.

The debug APK is for testing and is not a Play Store release package.
