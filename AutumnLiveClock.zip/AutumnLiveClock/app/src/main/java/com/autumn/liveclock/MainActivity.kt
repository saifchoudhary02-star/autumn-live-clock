package com.autumn.liveclock

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dark = Color(0xFF24160F)
private val amber = Color(0xFFD97732)
private val cream = Color(0xFFFFE8C7)
private val scenes = listOf("Golden Forest", "Rainy Autumn", "Autumn Sunset", "Dark Autumn")
private val digitalStyles = listOf("Minimal Elegant", "Luxury Classic", "Cinematic Bold", "Artistic Handwritten")
private val analogStyles = listOf("Gold Luxury", "Minimal White", "Vintage Antique", "Glowing Cinematic")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AutumnApp() } }
}

@Composable
private fun AutumnApp() {
    val context = LocalContext.current
    var scene by remember { mutableStateOf(scenes[0]) }
    var clockType by remember { mutableStateOf("Digital") }
    var style by remember { mutableStateOf(digitalStyles[0]) }
    var is24 by remember { mutableStateOf(false) }
    var leaves by remember { mutableStateOf(true) }
    var rain by remember { mutableStateOf(false) }
    var fog by remember { mutableStateOf(true) }
    var fireflies by remember { mutableStateOf(true) }
    var particles by remember { mutableStateOf(true) }
    var showDate by remember { mutableStateOf(true) }
    var showBattery by remember { mutableStateOf(true) }
    var showWeather by remember { mutableStateOf(false) }
    val timePattern = if (is24) "HH:mm" else "hh:mm a"
    val time = remember(is24) { SimpleDateFormat(timePattern, Locale.getDefault()).format(Date()) }
    val palette = when (scene) {
        "Rainy Autumn" -> listOf(Color(0xFF182B32), Color(0xFF53666A), Color(0xFFB47B4A))
        "Autumn Sunset" -> listOf(Color(0xFF401D27), Color(0xFFB84F32), Color(0xFFE7A34B))
        "Dark Autumn" -> listOf(Color(0xFF090D0D), Color(0xFF25251D), Color(0xFF704322))
        else -> listOf(Color(0xFF18251A), Color(0xFF76502B), Color(0xFFD58A3B))
    }
    MaterialTheme(colorScheme = darkColorScheme(background = dark, surface = Color(0xFF39251A), primary = amber, onSurface = cream)) {
        Column(Modifier.fillMaxSize().background(dark).verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text("AUTUMN LIVE CLOCK", color = amber, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Make every moment\nfeel like autumn.", color = cream, fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().height(250.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(Brush.verticalGradient(palette))
                    // Layered forest silhouettes
                    for (i in 0..8) {
                        val x = size.width * i / 8f
                        val h = size.height * (0.25f + ((i * 37) % 50) / 100f)
                        drawLine(Color(0xFF172019).copy(alpha=.8f), Offset(x, size.height), Offset(x, size.height-h), 9f)
                        drawCircle(Color(0xFF273522).copy(alpha=.9f), size.width*.09f, Offset(x, size.height-h))
                    }
                    if (leaves) for (i in 0..18) {
                        val x = size.width * ((i * 53 % 97) / 100f)
                        val y = size.height * ((i * 29 % 93) / 100f)
                        rotate(i * 19f, pivot = Offset(x, y)) { drawOval(Color(0xFFE39A43).copy(alpha=.85f), Offset(x, y), androidx.compose.ui.geometry.Size(7f, 13f)) }
                    }
                    if (fog) drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x55E5D8C5), Color.Transparent)))
                    if (rain) for (i in 0..45) { val x=size.width*(i%13)/13f; val y=size.height*(i*17%100)/100f; drawLine(Color(0x99D9E8E8), Offset(x,y), Offset(x-5,y+17), 1.2f) }
                    if (fireflies) for (i in 0..12) drawCircle(Color(0xFFFFD77A).copy(alpha=.8f), 2.5f, Offset(size.width*((i*31%97)/100f), size.height*((i*47%90)/100f)))
                }
                Column(Modifier.align(Alignment.TopCenter).padding(top=28.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(time, color=cream, fontSize=if(clockType=="Digital") 43.sp else 38.sp, fontWeight=FontWeight.Light)
                    if (showDate) Text(SimpleDateFormat("EEEE, d MMMM", Locale.ENGLISH).format(Date()), color=cream.copy(alpha=.85f), fontSize=13.sp)
                    if (clockType == "Analog") { Spacer(Modifier.height(8.dp)); AnalogFace() }
                }
                Text(scene.uppercase(), Modifier.align(Alignment.BottomCenter).padding(12.dp), color=cream.copy(alpha=.85f), fontSize=11.sp, letterSpacing=2.sp)
            }
            Spacer(Modifier.height(20.dp))
            Section("SCENE STUDIO") { ChoiceRow(scenes, scene) { scene=it } }
            Section("CLOCK STUDIO") {
                ChoiceRow(listOf("Digital", "Analog"), clockType) { clockType=it; style=if(it=="Digital") digitalStyles[0] else analogStyles[0] }
                ChoiceRow(if(clockType=="Digital") digitalStyles else analogStyles, style) { style=it }
                Row(verticalAlignment=Alignment.CenterVertically) { Text("24-hour format", color=cream, modifier=Modifier.weight(1f)); Switch(is24, {is24=it}) }
            }
            Section("ANIMATION STUDIO") {
                Toggle("Falling leaves", leaves) {leaves=it}; Toggle("Rain", rain) {rain=it}; Toggle("Fog and mist", fog) {fog=it}; Toggle("Fireflies", fireflies) {fireflies=it}; Toggle("Floating particles", particles) {particles=it}
            }
            Section("INFORMATION") { Toggle("Date and weekday", showDate) {showDate=it}; Toggle("Battery percentage (planned integration)", showBattery) {showBattery=it}; Toggle("Weather (provider setup required)", showWeather) {showWeather=it} }
            Section("LIVE WALLPAPER") {
                Text("Use this autumn scene behind your home-screen icons.", color=cream.copy(alpha=.8f), fontSize=13.sp)
                Button(onClick = { try { val intent=Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(context, AutumnWallpaperService::class.java)); context.startActivity(intent) } catch (_: Exception) {} }, modifier=Modifier.fillMaxWidth()) { Text("Preview / Apply live wallpaper") }
            }
            Text("AUTUMN LIVE CLOCK • VERSION 1.0", color=cream.copy(alpha=.45f), fontSize=10.sp, modifier=Modifier.align(Alignment.CenterHorizontally).padding(20.dp))
        }
    }
}

@Composable private fun AnalogFace() { Canvas(Modifier.size(92.dp)) { val c=Offset(size.width/2,size.height/2); drawCircle(cream, size.minDimension/2, style=Stroke(3f)); drawLine(cream,c,Offset(c.x,c.y-25f),4f); drawLine(amber,c,Offset(c.x+20f,c.y+12f),3f); drawCircle(amber,4f,c) } }
@Composable private fun Section(title:String, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxWidth().padding(top=18.dp)) { Text(title, color=amber, fontSize=12.sp, fontWeight=FontWeight.Bold, letterSpacing=1.5.sp); Spacer(Modifier.height(8.dp)); Column(Modifier.fillMaxWidth().background(Color(0xFF332219), RoundedCornerShape(16.dp)).padding(14.dp), content=content) } }
@Composable private fun ChoiceRow(items:List<String>, selected:String, onPick:(String)->Unit) { Column { items.chunked(2).forEach { pair -> Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) { pair.forEach { item -> FilterChip(selected=item==selected,onClick={onPick(item)},label={Text(item,fontSize=11.sp)},modifier=Modifier.weight(1f)) } } } } }
@Composable private fun Toggle(label:String, checked:Boolean, onChange:(Boolean)->Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) { Text(label, color=cream, fontSize=13.sp, modifier=Modifier.weight(1f)); Switch(checked,onChange) } }
