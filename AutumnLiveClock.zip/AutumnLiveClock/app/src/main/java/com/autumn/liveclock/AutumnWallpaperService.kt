package com.autumn.liveclock

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import kotlin.random.Random

class AutumnWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AutumnEngine()
    inner class AutumnEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val leaves = List(28) { Leaf(Random.nextFloat(), Random.nextFloat(), 2f + Random.nextFloat()*5f, Random.nextFloat()*2f-1f) }
        private val drawTask = object : Runnable { override fun run() { drawFrame(); if (visible) handler.postDelayed(this, 50) } }
        override fun onVisibilityChanged(visible: Boolean) { this.visible=visible; if(visible) { handler.removeCallbacks(drawTask); handler.post(drawTask) } else handler.removeCallbacks(drawTask) }
        override fun onSurfaceChanged(holder: SurfaceHolder, format:Int, width:Int, height:Int) { super.onSurfaceChanged(holder,format,width,height); drawFrame() }
        override fun onSurfaceDestroyed(holder:SurfaceHolder) { visible=false; handler.removeCallbacks(drawTask); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() { visible=false; handler.removeCallbacks(drawTask); super.onDestroy() }
        private fun drawFrame() {
            val holder=surfaceHolder; var canvas:Canvas?=null
            try { canvas=holder.lockCanvas(); if(canvas!=null) {
                val w=canvas.width.toFloat(); val h=canvas.height.toFloat()
                paint.shader=LinearGradient(0f,0f,0f,h, intArrayOf(Color.rgb(24,37,26),Color.rgb(117,75,37),Color.rgb(31,24,18)), null, Shader.TileMode.CLAMP)
                canvas.drawRect(0f,0f,w,h,paint); paint.shader=null
                for(i in 0..11) { val x=w*i/11f; val top=h*(.35f+((i*19)%45)/100f); paint.color=Color.rgb(28,37,27); canvas.drawRect(x-5,top,x+5,h,paint); canvas.drawCircle(x,top, w*.075f,paint) }
                for(leaf in leaves) { leaf.y=(leaf.y+.004f) % 1f; leaf.x=(leaf.x+leaf.drift*.001f+1f)%1f; paint.color=Color.rgb(218,130+(leaf.y*55).toInt(),48); canvas.save(); canvas.rotate(leaf.y*360,w*leaf.x,h*leaf.y); canvas.drawOval(w*leaf.x,h*leaf.y,w*leaf.x+leaf.size,h*leaf.y+leaf.size*1.8f,paint); canvas.restore() }
            } } catch (_:Exception) {} finally { if(canvas!=null) holder.unlockCanvasAndPost(canvas) }
        }
        private data class Leaf(var x:Float,var y:Float,val size:Float,val drift:Float)
    }
}
